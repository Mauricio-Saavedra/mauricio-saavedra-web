# Instrucciones

Puedes moverte con las flechas del teclado o con 'WASD'.
Puedes iniciar el jeuego clicando en el label "Comenzar", o presionando la barra espaciadora.

Nota: El ejecutable (.exe) no sirve fuera de su carpeta, si quieres ponerlo en un lugar más accesible, da click derecho y crea un 'Acceso directo', ese si puede estar dónde sea.

## Mecanicas

1. El juego consiste en esquivar la basura del mar.
2. Ganas puntos por permanecer en vida.
3. No hay posibilidad de ganar, las tottugas (y otras criaturas marinas) luchan por sobrevivir a la contaminación sin descanso.

### Extra

El juego era una manera de aprender a utilizar Godot, no tenía intención de nada, pero la idea me surgió (de ahí el nombre de la carpeta 'Dodge...').
Tengo en mente tres juegos más, así como renovar mi portafolio web haciendolo con @Blazor.

